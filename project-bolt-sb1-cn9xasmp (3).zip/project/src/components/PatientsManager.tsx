import React, { useState } from 'react';
import { Search, Plus, Edit, Eye, Phone, Mail, MapPin, Filter } from 'lucide-react';

const PatientsManager: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const patients = [
    {
      id: 1,
      name: 'أحمد محمد علي',
      age: 35,
      phone: '05012345678',
      email: 'ahmed@email.com',
      address: 'الرياض، حي النخيل',
      lastVisit: '2024-01-15',
      condition: 'مريض السكري',
      status: 'نشط'
    },
    {
      id: 2,
      name: 'فاطمة سعد الغامدي',
      age: 28,
      phone: '05098765432',
      email: 'fatima@email.com',
      address: 'جدة، حي الصفا',
      lastVisit: '2024-01-20',
      condition: 'ضغط الدم',
      status: 'نشط'
    },
    {
      id: 3,
      name: 'محمد خالد العتيبي',
      age: 42,
      phone: '05055555555',
      email: 'mohammed@email.com',
      address: 'الدمام، حي الفيصلية',
      lastVisit: '2024-01-10',
      condition: 'أمراض القلب',
      status: 'متابعة'
    }
  ];

  const filteredPatients = patients.filter(patient =>
    patient.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.phone.includes(searchTerm) ||
    patient.condition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* العنوان والأدوات */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">إدارة المرضى</h1>
          <p className="text-gray-600">إدارة ومتابعة بيانات المرضى</p>
        </div>
        
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 space-x-reverse"
        >
          <Plus size={20} />
          <span>إضافة مريض جديد</span>
        </button>
      </div>

      {/* شريط البحث والفلترة */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="بحث عن مريض بالاسم، الهاتف أو الحالة المرضية..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
            />
            <Search size={20} className="absolute right-4 top-3.5 text-gray-400" />
          </div>
          
          <button className="px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2 space-x-reverse">
            <Filter size={20} className="text-gray-500" />
            <span>فلترة</span>
          </button>
        </div>
      </div>

      {/* قائمة المرضى */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-800">
            قائمة المرضى ({filteredPatients.length})
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-4 text-right text-sm font-medium text-gray-500">اسم المريض</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-gray-500">العمر</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-gray-500">رقم الهاتف</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-gray-500">الحالة المرضية</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-gray-500">آخر زيارة</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-gray-500">الحالة</th>
                <th className="px-6 py-4 text-right text-sm font-medium text-gray-500">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredPatients.map((patient) => (
                <tr key={patient.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-800">{patient.name}</div>
                      <div className="text-sm text-gray-500 flex items-center space-x-1 space-x-reverse">
                        <Mail size={12} />
                        <span>{patient.email}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-800 text-right">{patient.age} سنة</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-800">
                      <Phone size={12} />
                      <span>{patient.phone}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-800 text-right">{patient.condition}</td>
                  <td className="px-6 py-4 text-sm text-gray-800 text-right">{patient.lastVisit}</td>
                  <td className="px-6 py-4 text-right">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      patient.status === 'نشط' 
                        ? 'text-green-600 bg-green-100' 
                        : 'text-orange-600 bg-orange-100'
                    }`}>
                      {patient.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <button className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors">
                        <Eye size={16} />
                      </button>
                      <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                        <Edit size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredPatients.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-2">
              <Search size={48} className="mx-auto" />
            </div>
            <p className="text-gray-500">لا توجد نتائج للبحث "{searchTerm}"</p>
          </div>
        )}
      </div>

      {/* نموذج إضافة مريض جديد */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-bold text-gray-800">إضافة مريض جديد</h3>
            </div>
            
            <form className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  اسم المريض الكامل
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                  placeholder="أدخل اسم المريض"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    العمر
                  </label>
                  <input
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                    placeholder="العمر"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    الجنس
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right">
                    <option>ذكر</option>
                    <option>أنثى</option>
                  </select>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  رقم الهاتف
                </label>
                <input
                  type="tel"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                  placeholder="05xxxxxxxx"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  البريد الإلكتروني
                </label>
                <input
                  type="email"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                  placeholder="example@email.com"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  العنوان
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                  rows={3}
                  placeholder="أدخل العنوان كاملاً"
                />
              </div>
              
              <div className="flex space-x-3 space-x-reverse pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  حفظ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientsManager;