import React, { useState } from 'react';
import { Search, Plus, Edit, Eye, Phone, Mail, MapPin, Filter, Stethoscope, Calendar, Users } from 'lucide-react';

const DoctorsManager: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedSpecialty, setSelectedSpecialty] = useState('');

  const doctors = [
    {
      id: 1,
      name: 'د. سامي الأحمد',
      specialty: 'طب عام',
      phone: '05012345678',
      email: 'sami.ahmad@clinic.com',
      address: 'الرياض، حي النخيل',
      experience: '15 سنة',
      patients: 245,
      appointments: 89,
      status: 'نشط',
      schedule: 'الأحد - الخميس، 8:00 ص - 4:00 م',
      qualifications: 'بكالوريوس طب وجراحة، ماجستير طب عام'
    },
    {
      id: 2,
      name: 'د. ليلى حسن',
      specialty: 'أمراض نساء وولادة',
      phone: '05098765432',
      email: 'layla.hassan@clinic.com',
      address: 'جدة، حي الصفا',
      experience: '12 سنة',
      patients: 189,
      appointments: 76,
      status: 'نشط',
      schedule: 'السبت - الأربعاء، 9:00 ص - 5:00 م',
      qualifications: 'بكالوريوس طب وجراحة، اختصاص أمراض نساء وولادة'
    },
    {
      id: 3,
      name: 'د. عمر الحسين',
      specialty: 'أمراض القلب',
      phone: '05055555555',
      email: 'omar.hussein@clinic.com',
      address: 'الدمام، حي الفيصلية',
      experience: '20 سنة',
      patients: 156,
      appointments: 64,
      status: 'نشط',
      schedule: 'الأحد - الخميس، 10:00 ص - 6:00 م',
      qualifications: 'بكالوريوس طب وجراحة، دكتوراه أمراض القلب'
    },
    {
      id: 4,
      name: 'د. منى عبدالله',
      specialty: 'طب أطفال',
      phone: '05077777777',
      email: 'mona.abdullah@clinic.com',
      address: 'الرياض، حي العليا',
      experience: '8 سنوات',
      patients: 198,
      appointments: 58,
      status: 'إجازة',
      schedule: 'السبت - الأربعاء، 8:00 ص - 3:00 م',
      qualifications: 'بكالوريوس طب وجراحة، اختصاص طب أطفال'
    }
  ];

  const specialties = ['جميع التخصصات', 'طب عام', 'أمراض نساء وولادة', 'أمراض القلب', 'طب أطفال', 'جراحة عامة', 'طب عيون'];

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = doctor.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doctor.specialty.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doctor.phone.includes(searchTerm);
    
    const matchesSpecialty = selectedSpecialty === '' || selectedSpecialty === 'جميع التخصصات' || doctor.specialty === selectedSpecialty;
    
    return matchesSearch && matchesSpecialty;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'نشط':
        return 'text-green-600 bg-green-100';
      case 'إجازة':
        return 'text-orange-600 bg-orange-100';
      case 'غير نشط':
        return 'text-red-600 bg-red-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* العنوان والأدوات */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">إدارة الأطباء</h1>
          <p className="text-gray-600">إدارة ومتابعة بيانات الأطباء والاختصاصات</p>
        </div>
        
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 space-x-reverse"
        >
          <Plus size={20} />
          <span>إضافة طبيب جديد</span>
        </button>
      </div>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{doctors.length}</div>
            <div className="text-sm text-gray-600">إجمالي الأطباء</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{doctors.filter(d => d.status === 'نشط').length}</div>
            <div className="text-sm text-gray-600">أطباء نشطين</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{doctors.reduce((sum, d) => sum + d.patients, 0)}</div>
            <div className="text-sm text-gray-600">إجمالي المرضى</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{doctors.reduce((sum, d) => sum + d.appointments, 0)}</div>
            <div className="text-sm text-gray-600">إجمالي المواعيد</div>
          </div>
        </div>
      </div>

      {/* شريط البحث والفلترة */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="بحث عن طبيب بالاسم، التخصص أو رقم الهاتف..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
            />
            <Search size={20} className="absolute right-4 top-3.5 text-gray-400" />
          </div>
          
          <select
            value={selectedSpecialty}
            onChange={(e) => setSelectedSpecialty(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
          >
            {specialties.map(specialty => (
              <option key={specialty} value={specialty}>{specialty}</option>
            ))}
          </select>
          
          <button className="px-4 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2 space-x-reverse">
            <Filter size={20} className="text-gray-500" />
            <span>فلترة متقدمة</span>
          </button>
        </div>
      </div>

      {/* قائمة الأطباء */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-800">
            قائمة الأطباء ({filteredDoctors.length})
          </h2>
        </div>

        <div className="p-6">
          <div className="grid gap-6">
            {filteredDoctors.map((doctor) => (
              <div key={doctor.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-sm transition-all">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  {/* معلومات الطبيب الأساسية */}
                  <div className="flex items-start space-x-4 space-x-reverse">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <Stethoscope size={24} className="text-blue-600" />
                    </div>
                    
                    <div className="flex-1 text-right">
                      <h3 className="text-lg font-bold text-gray-800">{doctor.name}</h3>
                      <p className="text-blue-600 font-medium">{doctor.specialty}</p>
                      <p className="text-sm text-gray-600 mt-1">{doctor.qualifications}</p>
                      
                      <div className="flex flex-wrap gap-4 mt-3 text-sm text-gray-600">
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <Phone size={12} />
                          <span>{doctor.phone}</span>
                        </div>
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <Mail size={12} />
                          <span>{doctor.email}</span>
                        </div>
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <MapPin size={12} />
                          <span>{doctor.address}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* الإحصائيات والحالة */}
                  <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-gray-800">{doctor.experience}</div>
                        <div className="text-xs text-gray-500">خبرة</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-blue-600">{doctor.patients}</div>
                        <div className="text-xs text-gray-500">مريض</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-green-600">{doctor.appointments}</div>
                        <div className="text-xs text-gray-500">موعد</div>
                      </div>
                    </div>

                    <div className="flex flex-col items-end space-y-2">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(doctor.status)}`}>
                        {doctor.status}
                      </span>
                      
                      <div className="flex space-x-2 space-x-reverse">
                        <button className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors" title="عرض التفاصيل">
                          <Eye size={16} />
                        </button>
                        <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="تعديل">
                          <Edit size={16} />
                        </button>
                        <button className="p-2 text-green-600 hover:bg-green-100 rounded-lg transition-colors" title="المواعيد">
                          <Calendar size={16} />
                        </button>
                        <button className="p-2 text-purple-600 hover:bg-purple-100 rounded-lg transition-colors" title="المرضى">
                          <Users size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* جدول العمل */}
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-600">
                    <Calendar size={14} />
                    <span className="font-medium">جدول العمل:</span>
                    <span>{doctor.schedule}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredDoctors.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-2">
                <Stethoscope size={48} className="mx-auto" />
              </div>
              <p className="text-gray-500">لا توجد نتائج للبحث "{searchTerm}"</p>
            </div>
          )}
        </div>
      </div>

      {/* نموذج إضافة طبيب جديد */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-bold text-gray-800">إضافة طبيب جديد</h3>
            </div>
            
            <form className="p-6 space-y-6">
              {/* المعلومات الأساسية */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    اسم الطبيب الكامل
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                    placeholder="د. أحمد محمد"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    التخصص
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right">
                    <option>طب عام</option>
                    <option>أمراض نساء وولادة</option>
                    <option>أمراض القلب</option>
                    <option>طب أطفال</option>
                    <option>جراحة عامة</option>
                    <option>طب عيون</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    رقم الهاتف
                  </label>
                  <input
                    type="tel"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                    placeholder="05xxxxxxxx"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    البريد الإلكتروني
                  </label>
                  <input
                    type="email"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                    placeholder="doctor@clinic.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  المؤهلات العلمية
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                  rows={3}
                  placeholder="بكالوريوس طب وجراحة، ماجستير..."
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    سنوات الخبرة
                  </label>
                  <input
                    type="number"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                    placeholder="10"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    الحالة
                  </label>
                  <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right">
                    <option>نشط</option>
                    <option>إجازة</option>
                    <option>غير نشط</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  جدول العمل
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                  placeholder="الأحد - الخميس، 8:00 ص - 4:00 م"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  العنوان
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                  rows={2}
                  placeholder="أدخل العنوان كاملاً"
                />
              </div>
              
              <div className="flex space-x-3 space-x-reverse pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  حفظ الطبيب
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DoctorsManager;