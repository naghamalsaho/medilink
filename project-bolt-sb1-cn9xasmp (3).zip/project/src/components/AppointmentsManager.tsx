import React, { useState } from 'react';
import { Calendar, Clock, Plus, Filter, CheckCircle, XCircle, AlertCircle } from 'lucide-react';

const AppointmentsManager: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [showAddForm, setShowAddForm] = useState(false);

  const appointments = [
    {
      id: 1,
      time: '09:00',
      patient: 'أحمد محمد علي',
      doctor: 'د. سامي الأحمد',
      type: 'كشف عام',
      status: 'confirmed',
      duration: 30,
      notes: 'مراجعة دورية'
    },
    {
      id: 2,
      time: '09:30',
      patient: 'فاطمة سعد الغامدي',
      doctor: 'د. ليلى حسن',
      type: 'متابعة',
      status: 'pending',
      duration: 30,
      notes: 'متابعة نتائج التحاليل'
    },
    {
      id: 3,
      time: '10:00',
      patient: 'محمد خالد العتيبي',
      doctor: 'د. عمر الحسين',
      type: 'استشارة',
      status: 'completed',
      duration: 45,
      notes: 'استشارة قلبية'
    },
    {
      id: 4,
      time: '10:45',
      patient: 'عائشة أحمد',
      doctor: 'د. منى عبدالله',
      type: 'فحص دوري',
      status: 'cancelled',
      duration: 30,
      notes: 'ألغي الموعد'
    },
    {
      id: 5,
      time: '11:15',
      patient: 'سالم علي النهدي',
      doctor: 'د. سامي الأحمد',
      type: 'كشف عام',
      status: 'confirmed',
      duration: 30,
      notes: ''
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
        return <CheckCircle size={16} className="text-green-500" />;
      case 'pending':
        return <AlertCircle size={16} className="text-orange-500" />;
      case 'completed':
        return <CheckCircle size={16} className="text-blue-500" />;
      case 'cancelled':
        return <XCircle size={16} className="text-red-500" />;
      default:
        return <Clock size={16} className="text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'مؤكد';
      case 'pending':
        return 'في الانتظار';
      case 'completed':
        return 'مكتمل';
      case 'cancelled':
        return 'ملغي';
      default:
        return 'غير محدد';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'text-green-600 bg-green-100 border-green-200';
      case 'pending':
        return 'text-orange-600 bg-orange-100 border-orange-200';
      case 'completed':
        return 'text-blue-600 bg-blue-100 border-blue-200';
      case 'cancelled':
        return 'text-red-600 bg-red-100 border-red-200';
      default:
        return 'text-gray-600 bg-gray-100 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* العنوان والأدوات */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">إدارة المواعيد</h1>
          <p className="text-gray-600">جدولة ومتابعة مواعيد المرضى</p>
        </div>
        
        <button
          onClick={() => setShowAddForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 space-x-reverse"
        >
          <Plus size={20} />
          <span>موعد جديد</span>
        </button>
      </div>

      {/* تحديد التاريخ والفلترة */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <div className="flex items-center space-x-3 space-x-reverse">
            <Calendar size={20} className="text-gray-500" />
            <label className="text-sm font-medium text-gray-700">التاريخ:</label>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div className="flex items-center space-x-2 space-x-reverse">
            <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2 space-x-reverse">
              <Filter size={16} />
              <span className="text-sm">فلترة</span>
            </button>
          </div>
        </div>
      </div>

      {/* إحصائيات اليوم */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{appointments.filter(a => a.status === 'confirmed').length}</div>
            <div className="text-sm text-gray-600">مواعيد مؤكدة</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{appointments.filter(a => a.status === 'pending').length}</div>
            <div className="text-sm text-gray-600">في الانتظار</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{appointments.filter(a => a.status === 'completed').length}</div>
            <div className="text-sm text-gray-600">مكتملة</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{appointments.filter(a => a.status === 'cancelled').length}</div>
            <div className="text-sm text-gray-600">ملغية</div>
          </div>
        </div>
      </div>

      {/* جدول المواعيد */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-800">
            مواعيد يوم {new Date(selectedDate).toLocaleDateString('ar-SA')}
          </h2>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            {appointments.map((appointment) => (
              <div
                key={appointment.id}
                className={`border rounded-lg p-4 hover:shadow-sm transition-all ${getStatusColor(appointment.status)}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className="text-center">
                      <div className="text-lg font-bold text-gray-800">{appointment.time}</div>
                      <div className="text-xs text-gray-500">{appointment.duration} دقيقة</div>
                    </div>
                    
                    <div className="border-r border-gray-300 pr-4 text-right">
                      <h3 className="font-medium text-gray-800">{appointment.patient}</h3>
                      <p className="text-sm text-gray-600">{appointment.doctor}</p>
                      <p className="text-xs text-gray-500">{appointment.type}</p>
                      {appointment.notes && (
                        <p className="text-xs text-gray-400 mt-1">{appointment.notes}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 space-x-reverse">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      {getStatusIcon(appointment.status)}
                      <span className="text-sm font-medium">{getStatusText(appointment.status)}</span>
                    </div>
                    
                    <div className="flex space-x-2 space-x-reverse">
                      {appointment.status === 'pending' && (
                        <>
                          <button className="px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700 transition-colors">
                            تأكيد
                          </button>
                          <button className="px-3 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-700 transition-colors">
                            إلغاء
                          </button>
                        </>
                      )}
                      {appointment.status === 'confirmed' && (
                        <button className="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 transition-colors">
                          مكتمل
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* نموذج إضافة موعد جديد */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <h3 className="text-lg font-bold text-gray-800">حجز موعد جديد</h3>
            </div>
            
            <form className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  اسم المريض
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right">
                  <option value="">اختر المريض</option>
                  <option>أحمد محمد علي</option>
                  <option>فاطمة سعد الغامدي</option>
                  <option>محمد خالد العتيبي</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  الطبيب
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right">
                  <option value="">اختر الطبيب</option>
                  <option>د. سامي الأحمد</option>
                  <option>د. ليلى حسن</option>
                  <option>د. عمر الحسين</option>
                </select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    التاريخ
                  </label>
                  <input
                    type="date"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                    الوقت
                  </label>
                  <input
                    type="time"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  نوع الزيارة
                </label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right">
                  <option>كشف عام</option>
                  <option>متابعة</option>
                  <option>استشارة</option>
                  <option>فحص دوري</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 text-right">
                  ملاحظات
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
                  rows={3}
                  placeholder="أضف أي ملاحظات إضافية..."
                />
              </div>
              
              <div className="flex space-x-3 space-x-reverse pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  حجز الموعد
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AppointmentsManager;