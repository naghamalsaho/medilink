import React from 'react';
import { HeartPulse, Stethoscope, Activity } from 'lucide-react';

const SplashScreen: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 flex items-center justify-center relative overflow-hidden">
      {/* خلفية متحركة */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 animate-pulse">
          <Stethoscope size={60} className="text-white" />
        </div>
        <div className="absolute top-32 right-20 animate-bounce">
          <Activity size={40} className="text-white" />
        </div>
        <div className="absolute bottom-20 left-32 animate-pulse">
          <HeartPulse size={50} className="text-white" />
        </div>
        <div className="absolute bottom-40 right-10 animate-bounce">
          <Stethoscope size={35} className="text-white" />
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="text-center z-10">
        {/* الشعار الرئيسي */}
        <div className="mb-8 animate-fadeInUp">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-white rounded-full shadow-2xl mb-6 animate-pulse">
            <HeartPulse size={40} className="text-blue-600" />
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-3 animate-slideInLeft">
            نظام إدارة المراكز الطبية
          </h1>
          
          <p className="text-xl text-blue-100 mb-2 animate-slideInRight">
            قسم السكرتيريا الطبية
          </p>
          
          <p className="text-lg text-blue-200 animate-fadeIn">
            نحو رعاية صحية متميزة
          </p>
        </div>

        {/* مؤشر التحميل */}
        <div className="animate-fadeInUp">
          <div className="w-64 h-2 bg-blue-300 bg-opacity-30 rounded-full mx-auto mb-4">
            <div className="h-full bg-gradient-to-r from-white to-blue-100 rounded-full animate-loading-bar"></div>
          </div>
          <p className="text-blue-100 text-sm">جاري التحميل...</p>
        </div>
      </div>

      {/* تأثيرات الخلفية */}
      <div className="absolute inset-0 bg-gradient-to-t from-blue-900 via-transparent to-transparent opacity-50"></div>
    </div>
  );
};

export default SplashScreen;