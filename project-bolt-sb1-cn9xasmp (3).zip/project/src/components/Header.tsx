import React from 'react';
import { Menu, Bell, Search, LogOut, User } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuClick, onLogout }) => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-4 lg:px-6 py-4">
      <div className="flex items-center justify-between">
        {/* الجانب الأيمن */}
        <div className="flex items-center space-x-4 space-x-reverse">
          <button
            onClick={onMenuClick}
            className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Menu size={20} className="text-gray-600" />
          </button>
          
          <div className="hidden md:block">
            <h1 className="text-xl font-bold text-gray-800">أهلاً وسهلاً</h1>
            <p className="text-sm text-gray-500">نظام إدارة السكرتيريا الطبية</p>
          </div>
        </div>

        {/* وسط الرأس - البحث */}
        <div className="hidden md:flex flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <input
              type="text"
              placeholder="بحث عن مريض، موعد أو ملف..."
              className="w-full px-4 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
            />
            <Search size={20} className="absolute right-3 top-2.5 text-gray-400" />
          </div>
        </div>

        {/* الجانب الأيسر */}
        <div className="flex items-center space-x-3 space-x-reverse">
          {/* الإشعارات */}
          <div className="relative">
            <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors relative">
              <Bell size={20} className="text-gray-600" />
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                3
              </span>
            </button>
          </div>

          {/* الملف الشخصي */}
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="hidden md:block text-right">
              <p className="text-sm font-medium text-gray-800">سارة أحمد</p>
              <p className="text-xs text-gray-500">سكرتيريا طبية</p>
            </div>
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
              <User size={20} className="text-blue-600" />
            </div>
          </div>

          {/* تسجيل الخروج */}
          <button
            onClick={onLogout}
            className="p-2 hover:bg-red-50 rounded-lg transition-colors group"
            title="تسجيل الخروج"
          >
            <LogOut size={20} className="text-gray-600 group-hover:text-red-600" />
          </button>
        </div>
      </div>

      {/* شريط البحث للموبايل */}
      <div className="md:hidden mt-3">
        <div className="relative">
          <input
            type="text"
            placeholder="بحث..."
            className="w-full px-4 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
          />
          <Search size={20} className="absolute right-3 top-2.5 text-gray-400" />
        </div>
      </div>
    </header>
  );
};

export default Header;