import React, { useState } from 'react';
import { FileText, Search, Plus, Eye, Download, Calendar, User } from 'lucide-react';

const MedicalRecords: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  const records = [
    {
      id: 1,
      patientName: 'أحمد محمد علي',
      recordType: 'تقرير طبي',
      doctor: 'د. سامي الأحمد',
      date: '2024-01-20',
      diagnosis: 'ارتفاع ضغط الدم',
      status: 'مكتمل',
      fileSize: '2.3 MB'
    },
    {
      id: 2,
      patientName: 'فاطمة سعد الغامدي',
      recordType: 'نتائج تحاليل',
      doctor: 'د. ليلى حسن',
      date: '2024-01-18',
      diagnosis: 'فحص دوري',
      status: 'قيد المراجعة',
      fileSize: '1.8 MB'
    },
    {
      id: 3,
      patientName: 'محمد خالد العتيبي',
      recordType: 'أشعة',
      doctor: 'د. عمر الحسين',
      date: '2024-01-15',
      diagnosis: 'فحص قلبي',
      status: 'مكتمل',
      fileSize: '5.2 MB'
    },
    {
      id: 4,
      patientName: 'عائشة أحمد',
      recordType: 'وصفة طبية',
      doctor: 'د. منى عبدالله',
      date: '2024-01-12',
      diagnosis: 'علاج مضاد حيوي',
      status: 'مكتمل',
      fileSize: '0.5 MB'
    }
  ];

  const filteredRecords = records.filter(record => {
    const matchesSearch = record.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.recordType.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         record.diagnosis.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = selectedFilter === 'all' || 
                         (selectedFilter === 'complete' && record.status === 'مكتمل') ||
                         (selectedFilter === 'pending' && record.status === 'قيد المراجعة');
    
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'مكتمل':
        return 'text-green-600 bg-green-100';
      case 'قيد المراجعة':
        return 'text-orange-600 bg-orange-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getRecordTypeIcon = (type: string) => {
    switch (type) {
      case 'تقرير طبي':
        return 'bg-blue-100 text-blue-600';
      case 'نتائج تحاليل':
        return 'bg-green-100 text-green-600';
      case 'أشعة':
        return 'bg-purple-100 text-purple-600';
      case 'وصفة طبية':
        return 'bg-orange-100 text-orange-600';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      {/* العنوان والأدوات */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">الملفات الطبية</h1>
          <p className="text-gray-600">إدارة ومتابعة الملفات والتقارير الطبية</p>
        </div>
        
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 space-x-reverse">
          <Plus size={20} />
          <span>إضافة ملف جديد</span>
        </button>
      </div>

      {/* البحث والفلترة */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="بحث في الملفات الطبية..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
            />
            <Search size={20} className="absolute right-4 top-3.5 text-gray-400" />
          </div>
          
          <select
            value={selectedFilter}
            onChange={(e) => setSelectedFilter(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
          >
            <option value="all">جميع الملفات</option>
            <option value="complete">مكتملة</option>
            <option value="pending">قيد المراجعة</option>
          </select>
        </div>
      </div>

      {/* إحصائيات سريعة */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{records.length}</div>
            <div className="text-sm text-gray-600">إجمالي الملفات</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{records.filter(r => r.status === 'مكتمل').length}</div>
            <div className="text-sm text-gray-600">ملفات مكتملة</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{records.filter(r => r.status === 'قيد المراجعة').length}</div>
            <div className="text-sm text-gray-600">قيد المراجعة</div>
          </div>
        </div>
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">
              {(records.reduce((sum, r) => sum + parseFloat(r.fileSize), 0)).toFixed(1)}
            </div>
            <div className="text-sm text-gray-600">MB إجمالي الحجم</div>
          </div>
        </div>
      </div>

      {/* قائمة الملفات */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <h2 className="text-lg font-bold text-gray-800">
            الملفات الطبية ({filteredRecords.length})
          </h2>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            {filteredRecords.map((record) => (
              <div key={record.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-sm transition-all">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${getRecordTypeIcon(record.recordType)}`}>
                      <FileText size={20} />
                    </div>
                    
                    <div className="text-right">
                      <h3 className="font-medium text-gray-800">{record.recordType}</h3>
                      <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-600 mt-1">
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <User size={12} />
                          <span>{record.patientName}</span>
                        </div>
                        <div className="flex items-center space-x-1 space-x-reverse">
                          <Calendar size={12} />
                          <span>{record.date}</span>
                        </div>
                      </div>
                      <p className="text-sm text-gray-500 mt-1">{record.doctor} - {record.diagnosis}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 space-x-reverse">
                    <div className="text-right">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(record.status)}`}>
                        {record.status}
                      </span>
                      <p className="text-xs text-gray-500 mt-1">{record.fileSize}</p>
                    </div>
                    
                    <div className="flex space-x-2 space-x-reverse">
                      <button className="p-2 text-blue-600 hover:bg-blue-100 rounded-lg transition-colors" title="عرض">
                        <Eye size={16} />
                      </button>
                      <button className="p-2 text-green-600 hover:bg-green-100 rounded-lg transition-colors" title="تحميل">
                        <Download size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredRecords.length === 0 && (
            <div className="text-center py-12">
              <div className="text-gray-400 mb-2">
                <FileText size={48} className="mx-auto" />
              </div>
              <p className="text-gray-500">لا توجد ملفات تطابق البحث</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MedicalRecords;