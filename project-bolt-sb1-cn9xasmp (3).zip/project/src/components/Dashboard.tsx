import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import DashboardContent from './DashboardContent';
import PatientsManager from './PatientsManager';
import DoctorsManager from './DoctorsManager';
import AppointmentsManager from './AppointmentsManager';
import MedicalRecords from './MedicalRecords';
import Reports from './Reports';
import Settings from './Settings';

interface DashboardProps {
  onLogout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const renderContent = () => {
    switch (activeTab) {
      case 'patients':
        return <PatientsManager />;
      case 'doctors':
        return <DoctorsManager />;
      case 'appointments':
        return <AppointmentsManager />;
      case 'records':
        return <MedicalRecords />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      default:
        return <DashboardContent />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* الشريط الجانبي - مثبت */}
      <div className="hidden lg:block lg:w-64 lg:fixed lg:inset-y-0 lg:z-50">
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab}
          isOpen={true}
          onClose={() => {}}
        />
      </div>

      {/* الشريط الجانبي للموبايل */}
      {sidebarOpen && (
        <>
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
          <div className="fixed right-0 top-0 h-full w-64 z-50 lg:hidden">
            <Sidebar 
              activeTab={activeTab} 
              setActiveTab={setActiveTab}
              isOpen={sidebarOpen}
              onClose={() => setSidebarOpen(false)}
            />
          </div>
        </>
      )}

      {/* المحتوى الرئيسي */}
      <div className="flex-1 lg:mr-64">
        <Header 
          onMenuClick={() => setSidebarOpen(!sidebarOpen)}
          onLogout={onLogout}
        />
        <main className="p-4 lg:p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;