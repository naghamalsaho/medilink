import React, { useState } from 'react';
import { BarChart3, TrendingUp, Calendar, Users, Clock, FileText, Download, Filter } from 'lucide-react';

const Reports: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const [selectedReport, setSelectedReport] = useState('overview');

  const statsData = {
    totalPatients: 1248,
    newPatients: 52,
    totalAppointments: 367,
    completedAppointments: 342,
    cancelledAppointments: 25,
    attendanceRate: 93.2
  };

  const monthlyData = [
    { month: 'يناير', appointments: 120, patients: 45 },
    { month: 'فبراير', appointments: 135, patients: 52 },
    { month: 'مارس', appointments: 142, patients: 48 },
    { month: 'أبريل', appointments: 158, patients: 67 },
    { month: 'مايو', appointments: 167, patients: 54 },
    { month: 'يونيو', appointments: 145, patients: 41 }
  ];

  const topDoctors = [
    { name: 'د. سامي الأحمد', appointments: 89, rating: 4.8 },
    { name: 'د. ليلى حسن', appointments: 76, rating: 4.9 },
    { name: 'د. عمر الحسين', appointments: 64, rating: 4.7 },
    { name: 'د. منى عبدالله', appointments: 58, rating: 4.6 }
  ];

  const reports = [
    {
      id: 'overview',
      title: 'نظرة عامة',
      description: 'ملخص شامل للأنشطة والإحصائيات',
      icon: BarChart3,
      color: 'blue'
    },
    {
      id: 'patients',
      title: 'تقرير المرضى',
      description: 'إحصائيات تفصيلية عن المرضى',
      icon: Users,
      color: 'green'
    },
    {
      id: 'appointments',
      title: 'تقرير المواعيد',
      description: 'تحليل المواعيد والحضور',
      icon: Calendar,
      color: 'purple'
    },
    {
      id: 'financial',
      title: 'التقرير المالي',
      description: 'الإيرادات والنفقات',
      icon: TrendingUp,
      color: 'orange'
    }
  ];

  return (
    <div className="space-y-6">
      {/* العنوان والأدوات */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">التقارير والإحصائيات</h1>
          <p className="text-gray-600">تحليل شامل لأداء المركز الطبي</p>
        </div>
        
        <div className="flex items-center space-x-3 space-x-reverse">
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2 space-x-reverse">
            <Download size={20} />
            <span>تصدير التقرير</span>
          </button>
        </div>
      </div>

      {/* فلاتر التقارير */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <div className="flex items-center space-x-3 space-x-reverse">
            <Filter size={20} className="text-gray-500" />
            <label className="text-sm font-medium text-gray-700">الفترة الزمنية:</label>
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
            >
              <option value="week">هذا الأسبوع</option>
              <option value="month">هذا الشهر</option>
              <option value="quarter">هذا الربع</option>
              <option value="year">هذا العام</option>
            </select>
          </div>
          
          <div className="flex items-center space-x-3 space-x-reverse">
            <label className="text-sm font-medium text-gray-700">نوع التقرير:</label>
            <select
              value={selectedReport}
              onChange={(e) => setSelectedReport(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-right"
            >
              {reports.map(report => (
                <option key={report.id} value={report.id}>{report.title}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* الإحصائيات الرئيسية */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Users size={24} className="text-blue-600" />
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-gray-800">{statsData.totalPatients.toLocaleString()}</div>
              <div className="text-sm text-gray-600">إجمالي المرضى</div>
              <div className="text-xs text-green-600 mt-1">+{statsData.newPatients} مريض جديد</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Calendar size={24} className="text-green-600" />
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-gray-800">{statsData.totalAppointments}</div>
              <div className="text-sm text-gray-600">إجمالي المواعيد</div>
              <div className="text-xs text-blue-600 mt-1">{statsData.completedAppointments} مكتمل</div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <TrendingUp size={24} className="text-purple-600" />
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-gray-800">{statsData.attendanceRate}%</div>
              <div className="text-sm text-gray-600">معدل الحضور</div>
              <div className="text-xs text-green-600 mt-1">+2.1% من الشهر الماضي</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* الرسم البياني */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">المواعيد الشهرية</h3>
          <div className="space-y-4">
            {monthlyData.map((data, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="text-sm font-medium text-gray-700 w-16 text-right">{data.month}</div>
                  <div className="flex-1 bg-gray-200 rounded-full h-3 max-w-32">
                    <div 
                      className="bg-blue-600 h-3 rounded-full"
                      style={{ width: `${(data.appointments / 200) * 100}%` }}
                    ></div>
                  </div>
                </div>
                <div className="text-sm font-bold text-gray-800">{data.appointments}</div>
              </div>
            ))}
          </div>
        </div>

        {/* أفضل الأطباء */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">أفضل الأطباء أداءً</h3>
          <div className="space-y-4">
            {topDoctors.map((doctor, index) => (
              <div key={index} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3 space-x-reverse">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <span className="text-blue-600 font-bold">{index + 1}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-gray-800">{doctor.name}</div>
                    <div className="text-sm text-gray-600">التقييم: {doctor.rating}/5</div>
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-gray-800">{doctor.appointments}</div>
                  <div className="text-xs text-gray-500">موعد</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ملخص التقارير */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-gray-800 mb-4">ملخص الأداء</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-2xl font-bold text-blue-600 mb-1">95%</div>
            <div className="text-sm text-gray-600">رضا المرضى</div>
          </div>
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-600 mb-1">12 min</div>
            <div className="text-sm text-gray-600">متوسط وقت الانتظار</div>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600 mb-1">4.7/5</div>
            <div className="text-sm text-gray-600">تقييم الخدمة</div>
          </div>
          <div className="text-center p-4 bg-orange-50 rounded-lg">
            <div className="text-2xl font-bold text-orange-600 mb-1">24/7</div>
            <div className="text-sm text-gray-600">ساعات العمل</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;