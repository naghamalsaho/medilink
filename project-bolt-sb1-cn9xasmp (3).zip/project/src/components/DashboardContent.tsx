import React from 'react';
import { 
  Users, 
  Calendar, 
  FileText, 
  Clock,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  UserPlus
} from 'lucide-react';

const DashboardContent: React.FC = () => {
  const stats = [
    {
      title: 'إجمالي المرضى',
      value: '1,248',
      change: '+12%',
      changeType: 'positive',
      icon: Users,
      color: 'blue'
    },
    {
      title: 'المواعيد اليوم',
      value: '23',
      change: '+5',
      changeType: 'positive',
      icon: Calendar,
      color: 'green'
    },
    {
      title: 'الملفات الجديدة',
      value: '8',
      change: '+3',
      changeType: 'positive',
      icon: FileText,
      color: 'purple'
    },
    {
      title: 'المواعيد المعلقة',
      value: '4',
      change: '-2',
      changeType: 'negative',
      icon: Clock,
      color: 'orange'
    }
  ];

  const recentAppointments = [
    {
      id: 1,
      patientName: 'أحمد محمد علي',
      doctor: 'د. سامي الأحمد',
      time: '09:30',
      status: 'confirmed',
      type: 'كشف عام'
    },
    {
      id: 2,
      patientName: 'فاطمة سعد',
      doctor: 'د. ليلى حسن',
      time: '10:15',
      status: 'waiting',
      type: 'متابعة'
    },
    {
      id: 3,
      patientName: 'محمد خالد',
      doctor: 'د. عمر الحسين',
      time: '11:00',
      status: 'completed',
      type: 'استشارة'
    },
    {
      id: 4,
      patientName: 'عائشة أحمد',
      doctor: 'د. منى عبدالله',
      time: '11:45',
      status: 'confirmed',
      type: 'فحص دوري'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'text-blue-600 bg-blue-100';
      case 'waiting':
        return 'text-orange-600 bg-orange-100';
      case 'completed':
        return 'text-green-600 bg-green-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'مؤكد';
      case 'waiting':
        return 'انتظار';
      case 'completed':
        return 'مكتمل';
      default:
        return 'غير محدد';
    }
  };

  return (
    <div className="space-y-6">
      {/* ترحيب */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">مرحباً بك، سارة أحمد</h1>
            <p className="text-blue-100">اليوم {new Date().toLocaleDateString('ar-SA')} - لديك 23 موعد جديد</p>
          </div>
          <div className="hidden md:block">
            <TrendingUp size={48} className="text-blue-200" />
          </div>
        </div>
      </div>

      {/* الإحصائيات */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                  stat.color === 'blue' ? 'bg-blue-100' :
                  stat.color === 'green' ? 'bg-green-100' :
                  stat.color === 'purple' ? 'bg-purple-100' :
                  'bg-orange-100'
                }`}>
                  <Icon size={24} className={
                    stat.color === 'blue' ? 'text-blue-600' :
                    stat.color === 'green' ? 'text-green-600' :
                    stat.color === 'purple' ? 'text-purple-600' :
                    'text-orange-600'
                  } />
                </div>
                <span className={`text-sm font-medium px-2 py-1 rounded-full ${
                  stat.changeType === 'positive' ? 'text-green-600 bg-green-100' : 'text-red-600 bg-red-100'
                }`}>
                  {stat.change}
                </span>
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-1">{stat.value}</h3>
              <p className="text-sm text-gray-600">{stat.title}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* المواعيد اليوم */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-gray-800">مواعيد اليوم</h2>
              <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                عرض الكل
              </button>
            </div>
          </div>
          <div className="p-6">
            <div className="space-y-4">
              {recentAppointments.map((appointment) => (
                <div key={appointment.id} className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <Users size={20} className="text-blue-600" />
                      </div>
                    </div>
                    <div className="flex-1 text-right">
                      <h3 className="text-sm font-medium text-gray-800">{appointment.patientName}</h3>
                      <p className="text-xs text-gray-500">{appointment.doctor} - {appointment.type}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <span className="text-sm font-medium text-gray-800">{appointment.time}</span>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(appointment.status)}`}>
                      {getStatusText(appointment.status)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* الإشعارات والمهام */}
        <div className="space-y-6">
          {/* الإشعارات */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 border-b border-gray-100">
              <h2 className="text-lg font-bold text-gray-800">إشعارات مهمة</h2>
            </div>
            <div className="p-4 space-y-3">
              <div className="flex items-start space-x-3 space-x-reverse">
                <AlertCircle size={16} className="text-red-500 mt-1 flex-shrink-0" />
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-800">موعد متأخر</p>
                  <p className="text-xs text-gray-600">أحمد محمد لم يحضر موعده</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 space-x-reverse">
                <CheckCircle size={16} className="text-green-500 mt-1 flex-shrink-0" />
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-800">تم تأكيد الموعد</p>
                  <p className="text-xs text-gray-600">فاطمة سعد أكدت موعدها</p>
                </div>
              </div>
              <div className="flex items-start space-x-3 space-x-reverse">
                <UserPlus size={16} className="text-blue-500 mt-1 flex-shrink-0" />
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-800">مريض جديد</p>
                  <p className="text-xs text-gray-600">تم تسجيل مريض جديد</p>
                </div>
              </div>
            </div>
          </div>

          {/* إحصائيات سريعة */}
          <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-6 border border-green-100">
            <h3 className="text-lg font-bold text-gray-800 mb-4">إحصائيات الأسبوع</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">مرضى جدد</span>
                <span className="font-bold text-green-600">+15</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">مواعيد مكتملة</span>
                <span className="font-bold text-blue-600">142</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">معدل الحضور</span>
                <span className="font-bold text-purple-600">94%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardContent;